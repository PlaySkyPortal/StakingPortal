<template>
  <div id="app">
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
          <router-link to="/" class="navbar-brand-text"> Staking Portal </router-link>
          <template v-if="getUserAccount">
            <button class="btn btn-primary btn-connect" @click="disconnect">
              {{ addrTruncation(getUserAccount) }}
            </button>
          </template>
          <button v-else class="btn btn-primary btn-connect" @click="onConnect">
            Connect Wallet
          </button>
        </div>
      </nav>
    </header>
    <div class="main-box">
      <router-view />
    </div>
  </div>
</template>

<script>
import Web3 from "web3";
import WalletConnectProvider from "@walletconnect/web3-provider";
import Web3Modal from "web3modal";
import { mapActions, mapGetters } from "vuex";

export default {
  name: "App",
  data() {
    return {
      showModal: false,
      isMetamaskInstalled: false,
      web3Modal: "",
    };
  },
  beforeMount() {
    const providerOptions = {
      walletconnect: {
        package: WalletConnectProvider,
        options: {
          rpc: {
            42220: "https://forno.celo.org",
          },
        },
      },
    };

    this.web3Modal = new Web3Modal({
      providerOptions,
      cacheProvider: false,
      disableInjectedProvider: false,
    });
  },
  mounted() {
    this.isMetamaskInstalled = window.ethereum ? true : false;
  },
  methods: {
    ...mapActions("wallet", [
      "SET_WEB3",
      "SET_USER_ACCOUNT",
      "SET_INSTANCE_STAKING",
      "SET_INSTANCE_MIGRATOR",
      "SET_INSTANCE_LAPIS",
      "SET_INSTANCE_LP",
    ]),
    addrTruncation(addr) {
      return addr.slice(0, 6) + "…" + addr.slice(addr.length - 4, addr.length);
    },
    disconnect() {
      this.SET_WEB3(null);
      this.SET_USER_ACCOUNT(null);
      this.SET_INSTANCE_STAKING(null);
      this.SET_INSTANCE_MIGRATOR(null);
      this.SET_INSTANCE_LAPIS(null);
      this.SET_INSTANCE_LP(null);
    },
    async onConnect() {
      try {
        let provider = await this.web3Modal.connect();
        this.onProvider(provider);
      } catch (e) {
        console.log("Could not get a wallet connection", e);
        return;
      }

      // if (name === "metamask") {
      //   await window.ethereum.request({ method: "eth_requestAccounts" });
      //   this.onProvider(window.ethereum);
      // } else if (name === "connect") {
      //   const provider = new WalletConnectProvider({
      //     rpc: {
      //       42220: "https://forno.celo.org",
      //     },
      //   });
      //   await provider.enable();
      //   this.onProvider(provider);
      // }
    },
    async onProvider(provider) {
      this.showModal = false;
      try {
        let web3 = new Web3(provider);
        this.SET_WEB3(web3);

        let accounts = await web3.eth.getAccounts();
        this.SET_USER_ACCOUNT(accounts[0]);

        let instanceLAPIS = new this.getWeb3.eth.Contract(
          this.getABILAPIS,
          this.getAddLAPIS
        );
        this.SET_INSTANCE_LAPIS(instanceLAPIS);

        let instanceMigrator = new this.getWeb3.eth.Contract(
          this.getABIMigrator,
          this.getAddMigrator
        );
        this.SET_INSTANCE_MIGRATOR(instanceMigrator);

        let instanceStaking = new this.getWeb3.eth.Contract(
          this.getABIStaking,
          this.getAddStaking
        );
        this.SET_INSTANCE_STAKING(instanceStaking);

        let instanceLP = new this.getWeb3.eth.Contract(this.getABILP, this.getAddLP);
        this.SET_INSTANCE_LP(instanceLP);
      } catch (e) {
        console.log("Could not get a wallet connection", e);
        return;
      }
    },
  },
  computed: {
    ...mapGetters("wallet", [
      "getWeb3",
      "getUserAccount",
      "getABILAPIS",
      "getAddLAPIS",
      "getABIMigrator",
      "getAddMigrator",
      "getABIStaking",
      "getAddStaking",
      "getABILP",
      "getAddLP",
    ]),
  },
};
</script>

<style>
@import "./css/styles.css";
</style>
