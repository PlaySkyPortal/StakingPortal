<template>
  <div class="row">
    <div class="col-12">
      <h1>LP Pool Farming</h1>
    </div>
    <div class="col-12 col-sm-6">
      <div class="d-flex justify-content-center">
        <button
          class="btn btn-primary w-75 my-4"
          @click="onApprove"
          :disabled="!getUserAccount"
        >
          {{ loadingApprove ? "Loading..." : "Approve LAPIS-CELO ULP" }}
        </button>
      </div>
      <div class="d-flex justify-content-center">
        <button
          class="btn btn-primary w-75 my-4"
          @click="onDeposit"
          :disabled="!getUserAccount"
        >
          {{ loadingDeposit ? "Loading..." : "Deposit LAPIS-CELO ULP" }}
        </button>
      </div>
      <div class="d-flex justify-content-center">
        <button
          class="btn btn-primary w-75 my-4"
          @click="onClaim"
          :disabled="!getUserAccount"
        >
          {{ loadingClaim ? "Loading..." : "Claim Reward" }}
        </button>
      </div>
      <div class="d-flex justify-content-center">
        <button
          class="btn btn-primary w-75 my-4"
          @click="onUnstake"
          :disabled="!getUserAccount"
        >
          {{ loadingUnStake ? "Loading..." : "UnStake" }}
        </button>
      </div>
    </div>
    <div class="col-12 col-sm-6">
      <div class="d-flex justify-content-center align-items-center" style="height: 100%">
        <div>
          <div class="d-flex justify-content-center">
            <h4>Weekly pool: {{ weeklyPool }} LAPIS</h4>
          </div>
          <div class="d-flex justify-content-center">
            <h4>Rewards: {{ rewards }} LAPIS</h4>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "LpPool",
  data() {
    return {
      weeklyPool: 0,
      rewards: 0,
      loadingApprove: false,
      loadingDeposit: false,
      loadingClaim: false,
      loadingUnStake: false,
    };
  },
  mounted() {
    if (this.getWeb3) {
      this.getWeeklyPool();
      this.getReward();
    }
  },
  methods: {
    async onClaim() {
      this.loadingClaim = true;
      this.getInstanceStaking.methods
        .getReward()
        .send({
          from: this.getUserAccount,
          value: 0,
        })
        .on("transactionHash", (hash) => {
          this.loadingClaim = false;
          console.log("Transaction hash", hash);
        })
        .on("receipt", (receipt) => {
          this.loadingClaim = false;
          this.$toasted.show("Claim successfully");
          console.log("Receipt: ", receipt);
        })
        .on("error", (error) => {
          this.loadingClaim = false;
          console.log("Error receipt: ", error);
        });
    },
    async onUnstake() {
      this.loadingUnStake = true;
      this.getInstanceStaking.methods
        .exit()
        .send({
          from: this.getUserAccount,
          value: 0,
        })
        .on("transactionHash", (hash) => {
          this.loadingUnStake = false;
          console.log("Transaction hash", hash);
        })
        .on("receipt", (receipt) => {
          this.loadingUnStake = false;
          this.$toasted.show("UnStake successfully");
          console.log("Receipt: ", receipt);
        })
        .on("error", (error) => {
          this.loadingUnStake = false;
          console.log("Error receipt: ", error);
        });
    },
    async onApprove() {
      this.loadingApprove = true;
      let userBalance = await this.getWeb3.eth.getBalance(this.getUserAccount);
      this.getInstanceLP.methods
        .approve(this.getAddStaking, userBalance)
        .send({
          from: this.getUserAccount,
          value: 0,
        })
        .on("transactionHash", (hash) => {
          this.loadingApprove = false;
          console.log("Transaction hash", hash);
        })
        .on("receipt", (receipt) => {
          this.loadingApprove = false;
          this.$toasted.show("Approve LAPIS successfully");
          console.log("Receipt: ", receipt);
        })
        .on("error", (error) => {
          this.loadingApprove = false;
          console.log("Error receipt: ", error);
        });
    },
    async onDeposit() {
      this.loadingDeposit = true;
      let userBalance = await this.getWeb3.eth.getBalance(this.getUserAccount);
      this.getInstanceStaking.methods
        .stake(userBalance)
        .send({
          from: this.getUserAccount,
          value: 0,
          fee: 0,
        })
        .on("transactionHash", (hash) => {
          this.loadingDeposit = false;
          console.log("Transaction hash", hash);
        })
        .on("receipt", (receipt) => {
          this.loadingDeposit = false;
          this.$toasted.show("Deposit LAPIS successfully");
          console.log("Receipt: ", receipt);
        })
        .on("error", (error) => {
          this.loadingDeposit = false;
          console.log("Error receipt: ", error);
        });
    },
    humanized(number, fix) {
      return Number(this.getWeb3.utils.fromWei(number.toString(), "ether")).toFixed(fix);
    },
    async getWeeklyPool() {
      let weeklyPool = await this.getInstanceStaking.methods
        .getRewardForDuration()
        .call();
      this.weeklyPool = this.humanized(weeklyPool);
    },
    async getReward() {
      let reward = await this.getInstanceStaking.methods
        .rewards(this.getUserAccount)
        .call();
      this.rewards = this.humanized(reward);
    },
  },
  computed: {
    ...mapGetters("wallet", [
      "getWeb3",
      "getUserAccount",
      "getInstanceLP",
      "getInstanceStaking",
      "getAddStaking",
    ]),
  },
  watch: {
    getUserAccount() {
      if (this.getWeb3) {
        this.getWeeklyPool();
        this.getReward();
      }
    },
  },
};
</script>

<style scoped>
.container {
  max-width: 1170px;
}
.error-message {
  position: relative;
  left: 5px;
  top: 5px;
  font-size: 13px;
  color: red;
}
</style>
