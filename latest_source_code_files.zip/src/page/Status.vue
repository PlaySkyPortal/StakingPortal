<template>
  <div class="row">
    <div class="col-12">
      <h1>Status</h1>
    </div>
    <div class="col-12 col-sm-6 text-center">
      <div class="d-flex justify-content-around">
        <button
          class="btn btn-primary w-75 my-5"
          @click="onTvl"
          :disabled="!getUserAccount"
        >
          TVL
        </button>
      </div>
    </div>
    <div class="col-12 col-sm-6 text-center">
      <div class="d-flex justify-content-around">
        <button class="btn btn-primary w-75 my-5" :disabled="true" @click="onTvl">
          Price: {{ price }} ULP
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";

export default {
  name: "Home",
  data() {
    return {
      price: 0,
    };
  },
  mounted() {},
  methods: {
    async onTvl() {
      let tokens = await this.getInstanceStaking.methods.balanceOf(this.getAddLP).call();
      this.price = this.humanized(tokens);
    },
    humanized(number, fix) {
      return Number(this.getWeb3.utils.fromWei(number.toString(), "ether")).toFixed(fix);
    },
  },
  computed: {
    ...mapGetters("wallet", [
      "getWeb3",
      "getUserAccount",
      "getAddLP",
      "getInstanceStaking",
    ]),
  },
};
</script>
