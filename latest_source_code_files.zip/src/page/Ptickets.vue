<template>
  <div class="row">
    <div class="col-12">
      <h1>pTickets Staking</h1>
    </div>
    <div class="col-12 col-sm-6">
      <div class="d-flex justify-content-center">
        <button class="btn btn-primary w-75 my-4" :disabled="!getUserAccount">
          Approve LAPIS
        </button>
      </div>
      <div class="d-flex justify-content-center">
        <button class="btn btn-primary w-75 my-4" :disabled="!getUserAccount">
          Stake LAPIS
        </button>
      </div>
      <div class="d-flex justify-content-center">
        <button class="btn btn-primary w-75 my-4" :disabled="!getUserAccount">
          Mint pTicket
        </button>
      </div>
      <div class="d-flex justify-content-center">
        <button class="btn btn-primary w-75 my-4" :disabled="!getUserAccount">
          UnStake
        </button>
      </div>
    </div>
    <div class="col-12 col-sm-6">
      <div class="d-flex justify-content-center align-items-center" style="height: 100%">
        <div>
          <div class="d-flex justify-content-center">
            <h4>Distribution rate: {{ weeklyPool }} LAPIS</h4>
          </div>
          <div class="d-flex justify-content-center">
            <h4>Mintable: {{ rewards }} LAPIS</h4>
          </div>
          <div class="d-flex justify-content-center">
            <h4>Maximum mintable tickets: {{ rewards }} LAPIS</h4>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "LpPool",
  data() {
    return {
      currentBalance: 0,
      weeklyPool: 0,
      rewards: 0,
    };
  },
  mounted() {
    if (this.getWeb3) {
      this.getBalance();
      this.getWeeklyPool();
      this.getReward();
    }
  },
  beforeDestroy() {},
  methods: {
    async onClaim() {
      this.getInstanceStaking.methods
        .getReward()
        .send({
          from: this.getUserAccount,
          value: 0,
        })
        .on("transactionHash", (hash) => {
          console.log("Transaction hash", hash);
        })
        .on("receipt", (receipt) => {
          console.log("Receipt: ", receipt);
        })
        .on("error", (error) => {
          console.log("Error receipt: ", error);
        });
    },
    async onUnstake() {
      this.getInstanceStaking.methods
        .exit()
        .send({
          from: this.getUserAccount,
          value: 0,
        })
        .on("transactionHash", (hash) => {
          console.log("Transaction hash", hash);
        })
        .on("receipt", (receipt) => {
          console.log("Receipt: ", receipt);
        })
        .on("error", (error) => {
          console.log("Error receipt: ", error);
        });
    },
    async onApprove() {
      let userBalance = await this.getInstanceLAPIS.methods
        .balanceOf(this.getUserAccount)
        .call();
      console.log(userBalance);
      this.getInstanceLAPIS.methods
        .approve(this.getAddMigrator, userBalance)
        .send({
          from: this.getUserAccount,
          value: 0,
        })
        .on("transactionHash", (hash) => {
          console.log("Transaction hash", hash);
        })
        .on("receipt", (receipt) => {
          console.log("Receipt: ", receipt);
        })
        .on("error", (error) => {
          console.log("Error receipt: ", error);
        });
    },
    async onMigrate() {
      let userBalance = await this.getInstanceLAPIS.methods
        .balanceOf(this.getUserAccount)
        .call();
      this.getInstanceMigrator.methods
        .migrateLAPIS(userBalance)
        .send({
          from: this.getUserAccount,
          value: 0,
        })
        .on("transactionHash", (hash) => {
          console.log("Transaction hash", hash);
        })
        .on("receipt", (receipt) => {
          console.log("Receipt: ", receipt);
        })
        .on("error", (error) => {
          console.log("Error receipt: ", error);
        });
    },
    humanized(number, fix) {
      return Number(this.getWeb3.utils.fromWei(number.toString(), "ether")).toFixed(fix);
    },
    async getBalance() {
      let balance = await this.getWeb3.eth.getBalance(this.getUserAccount);
      this.currentBalance = this.humanized(balance);
    },
    async getWeeklyPool() {
      let weeklyPool = await this.getInstanceStaking.methods
        .getRewardForDuration()
        .call();
      this.weeklyPool = this.humanized(weeklyPool);
    },
    async getReward() {
      let reward = await this.getInstanceStaking.methods
        .rewards(this.getUserAccount)
        .call();
      this.rewards = this.humanized(reward);
    },
  },
  computed: {
    ...mapGetters("wallet", [
      "getWeb3",
      "getUserAccount",
      "getAddMigrator",
      "getInstanceLAPIS",
      "getInstanceMigrator",

      "getInstanceStaking",
    ]),
  },
  watch: {
    getUserAccount() {
      if (this.getWeb3) {
        this.getBalance();
        this.getWeeklyPool();
        this.getReward();
      }
    },
  },
};
</script>

<style scoped>
.container {
  max-width: 1170px;
}
.error-message {
  position: relative;
  left: 5px;
  top: 5px;
  font-size: 13px;
  color: red;
}
</style>
