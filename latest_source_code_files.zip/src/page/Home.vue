<template>
  <div class="row">
    <div class="col-12">
      <h1>Welcome to Staking Portal</h1>
    </div>
    <div class="col-12 col-sm-6">
      <div class="d-flex justify-content-around">
        <router-link to="migrate" class="btn btn-primary w-75 my-5">
          Migrate
        </router-link>
      </div>
    </div>
    <div class="col-12 col-sm-6">
      <div class="d-flex justify-content-around">
        <router-link to="lpPool" class="btn btn-primary w-75 my-5">
          LP Pool Farming
        </router-link>
      </div>
    </div>
    <div class="col-12 col-sm-6">
      <div class="d-flex justify-content-around">
        <router-link to="pTicket" class="btn btn-primary w-75 my-5">
          pTickets Staking
        </router-link>
      </div>
    </div>
    <div class="col-12 col-sm-6">
      <div class="d-flex justify-content-around">
        <router-link to="status" class="btn btn-primary w-75 my-5"> Status </router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Home",
};
</script>
