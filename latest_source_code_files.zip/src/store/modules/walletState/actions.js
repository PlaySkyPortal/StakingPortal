const actions = {
  SET_WEB3({ commit }, payload) {
    commit("SET_WEB3", payload);
  },
  SET_USER_ACCOUNT({ commit }, payload) {
    commit("SET_USER_ACCOUNT", payload);
  },
  SET_INSTANCE_LAPIS({ commit }, payload) {
    commit("SET_INSTANCE_LAPIS", payload);
  },
  SET_INSTANCE_MIGRATOR({ commit }, payload) {
    commit("SET_INSTANCE_MIGRATOR", payload);
  },
  SET_INSTANCE_STAKING({ commit }, payload) {
    commit("SET_INSTANCE_STAKING", payload);
  },
  SET_INSTANCE_LP({ commit }, payload) {
    commit("SET_INSTANCE_LP", payload);
  }
};

export default actions;
