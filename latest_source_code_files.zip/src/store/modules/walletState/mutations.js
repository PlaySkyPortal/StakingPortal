const mutations = {
  SET_WEB3: (state, payload) => {
    state.web3 = payload;
  },
  SET_USER_ACCOUNT: (state, payload) => {
    state.userAccount = payload;
  },
  SET_INSTANCE_LAPIS: (state, payload) => {
    state.instanceLAPIS = payload;
  },
  SET_INSTANCE_MIGRATOR: (state, payload) => {
    state.instanceMigrator = payload;
  },
  SET_INSTANCE_STAKING: (state, payload) => {
    state.instanceStaking = payload;
  },
  SET_INSTANCE_LP: (state, payload) => {
    state.instanceLP = payload;
  },
};

export default mutations;
