const getters = {
  getWeb3: state => {
    return state.web3;
  },
  getUserAccount: state => {
    return state.userAccount;
  },
  getInstanceLAPIS: state => {
    return state.instanceLAPIS;
  },
  getAddLAPIS: state => {
    return state.contractAdd_LAPIS;
  },
  getABILAPIS: state => {
    return state.contractABI_LAPIS;
  },

  getInstanceMigrator: state => {
    return state.instanceMigrator;
  },
  getAddMigrator: state => {
    return state.contractAdd_Migrator;
  },
  getABIMigrator: state => {
    return state.contractABI_Migrator;
  },

  getInstanceStaking: state => {
    return state.instanceStaking;
  },
  getAddStaking: state => {
    return state.contractAdd_Staking;
  },
  getABIStaking: state => {
    return state.contractABI_Staking;
  },

  getInstanceLP: state => {
    return state.instanceLP;
  },
  getAddLP: state => {
    return state.contractAdd_LP;
  },
  getABILP: state => {
    return state.contractABI_LP;
  },

};

export default getters;
