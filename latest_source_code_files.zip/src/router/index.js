import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../page/Home.vue'
import Migrate from '../page/Migrate.vue'
import LpPoolFarming from '../page/LpPoolFarming.vue'
import Ptickets from '../page/Ptickets.vue'
import Status from '../page/Status.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/migrate',
    name: 'migrate',
    component: Migrate
  },
  {
    path: '/lpPool',
    name: 'lpPool',
    component: LpPoolFarming
  },
  {
    path: '/pTicket',
    name: 'pTicket',
    component: Ptickets
  },
  {
    path: '/status',
    name: 'status',
    component: Status
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
